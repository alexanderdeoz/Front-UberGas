export interface ClientModel {
    birthdate: Date;
    name: string;
    lastname: string;
    email: string;
    email_verified_at: string
    password: string
}