export interface DriverModel {
    name?: string;
    lastname?: string;
    birthay?: Date;
    phone?: string;
    placa?: string;
    vehicle?: string;
    email?: string
    email_verified_at?: string;
    password?: string;
}